#!/usr/bin/python3

import socket
import Server

server = Server.Server(10)

server.Run()
