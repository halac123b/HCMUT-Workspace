import Client
import socket
import UI
import GUII

#client = Client.Client()
#ui = UI.UI(client)
#ui.Run()

client = Client.Client()
client.run()
#
#gui.run()

#
#gui.run()

